#include<stdio.h>
#include <stdlib.h>
#include <stdbool.h>



typedef struct ListNode{
    int a;
    int b;
    struct ListNode* next;
}ListNode;

bool rm_fn(ListNode* node)
{
    return node->a==node->b;
}
void remove_if(ListNode** head)
{
    for(ListNode** curr=head;*curr!=NULL;)
    {
        ListNode* entry=*curr;
        printf("curr=%p,entry=%p",curr,entry);
        if(rm_fn(entry)==true)
        {
            *curr=entry->next;
            // free(entry);
            // entry=NULL;
        }
        else{
            curr=&entry->next;
        }
    }
    printf("\n");
}
void nodePrint(ListNode* head)
{
    while(head)
    {
        printf("a=%d,b=%d,next=%p  ",head->a,head->b,head->next);
        head=head->next;
    }
    printf("\n");
}

int main() {
    ListNode node_1;
    node_1.a=10,node_1.b=100;
    node_1.next=NULL;

    ListNode node_2;
    node_2.a=20,node_2.b=20;
    node_2.next=NULL;

    ListNode*phead=&node_1;
    phead->next=&node_2;

    printf("phead=%p,&phead=%p\n",phead,&phead);
    printf("phead a=%d,b=%d,next=%p ",phead->a,phead->b,phead->next);
    printf("&a=%p,&b=%p,&next=%p\n",&phead->a,&phead->b,&phead->next);

    printf("node_1 a=%d,b=%d,next=%p ",node_1.a,node_1.b,node_1.next);
    printf("&a=%p,&b=%p,&next=%p\n",&node_1.a,&node_1.b,&node_1.next);

    printf("node_2 a=%d,b=%d,next=%p ",node_2.a,node_2.b,node_2.next);
    printf("&a=%p,&b=%p,&next=%p\n",&node_2.a,&node_2.b,&node_2.next);

    nodePrint(phead);
    remove_if(&phead);
    nodePrint(phead);
    return 0;
}
